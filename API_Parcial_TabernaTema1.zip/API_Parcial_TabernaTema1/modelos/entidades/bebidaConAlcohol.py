from modelos.entidades.bebida import Bebida

class BebidaConAlcohol(Bebida):
    def __init__(self, nombre:str, costo:float, stock:int, mililitros:int, graduacionAlcoholica: float):
        super().__init__(nombre, costo, stock, mililitros)
        if not isinstance(graduacionAlcoholica, (int, float)) or graduacionAlcoholica < 0 or graduacionAlcoholica > 100:
            raise ValueError("La graduación alcohólica debe ser un número positivo")
        self.__graduacionAlcoholica = graduacionAlcoholica
    
    '''Agregacion de metodo de clase +fromDiccionario(dic: diccionario): BebidaConAlcohol'''
    @classmethod
    def fromDiccionario(cls, dic: dict):
        if "graduacionAlcoholica" not in dic:
            raise ValueError("La graduación alcohólica es requerida para bebidas con alcohol.")
        return cls(
            dic["nombre"],
            dic["costo"],
            dic["stock"],
            dic["mililitros"],
            dic["graduacionAlcoholica"] #trivial para el caso de bebidas con alcohol
        )

    def obtenerPrecio(self) -> float: #agregado el tipo de retorno
        return self._costo * 1.6
    
    def obtenerGraduacionAlcoholica(self) -> float: #agregado el tipo de retorno
        return self.__graduacionAlcoholica
    
    def establecerGraduacionAlcoholica(self, graduacionAlcoholica:float):
        if not isinstance(graduacionAlcoholica, (int, float)) or graduacionAlcoholica < 0 or graduacionAlcoholica > 100:
            raise ValueError("La graduación alcohólica debe ser un número positivo")
        self.__graduacionAlcoholica = graduacionAlcoholica

    def toDiccionario(self):
        return {
            "nombre": self._nombre,
            "costo": self._costo,
            "stock": self._stock,
            "mililitros": self._mililitros,
            "graduacionAlcoholica": self.__graduacionAlcoholica,
            "precio": self.obtenerPrecio()
        }