from modelos.entidades.bebida import Bebida

class BebidaSinAlcohol(Bebida):
    def __init__(self, nombre:str, costo:float, stock:int, mililitros:int, sabor: str, natural: bool):
        super().__init__(nombre, costo, stock, mililitros)
        if not isinstance(sabor, str) or not sabor.strip():
            raise ValueError("El sabor debe ser un string y no puede estar vacío")
        if not isinstance(natural, bool):
            raise ValueError("El atributo natural debe ser booleano")
        self.__sabor = sabor
        self.__natural = natural
    
    '''Agregacion de metodo de clase +fromDiccionario(dic: diccionario): BebidaSinAlcohol'''
    @classmethod
    def fromDiccionario(cls, dic: dict):
        """metdo de clase para crear una bebida sin alcohol a 
        partir de un diccionario"""
        return cls(
            dic["nombre"],
            dic["costo"],
            dic["stock"],
            dic["mililitros"],
            dic["sabor"],
            dic["natural"] #trivial para el caso de bebidas sin alcohol
        )

    def obtenerSabor(self) -> str: #agredado el tipo de retorno
        return self.__sabor
    
    def obtenerNatural(self) -> bool: #agredado el tipo de retorno
        return self.__natural
    
    '''agregacion metodo de instancia +esNatural(): bool'''
    def esNatural(self) -> bool:
        return self.__natural
    
    def establecerSabor(self, sabor:str):
        if not isinstance(sabor, str) or sabor == "":
            raise ValueError("El sabor no puede ser vacío")
        self.__sabor = sabor
    
    def establecerNatural(self, natural:bool):
        if not isinstance(natural, bool):
            raise ValueError("El atributo natural debe ser booleano")
        self.__natural = natural

    def obtenerPrecio(self):
        return self._costo * 1.5
    
    '''agregacion metodo de instancia +toDiccionario(): diccionario'''
    def toDiccionario(self):
        
        return {
            "nombre": self._nombre,
            "costo": self._costo,
            "stock": self._stock,
            "mililitros": self._mililitros,
            "sabor": self.__sabor,
            "natural": self.__natural
        }